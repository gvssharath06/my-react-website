import { useState, useEffect, useRef } from "react";
import { supabase } from "./utils/supabase";
import "./App.css";

const BUCKET = "memory-photos";
const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MAX_FILE_MB = 50;

// Must match the email used in the Supabase trips policies
const DEVELOPER_EMAIL = "gvssharath06@gmail.com";

// Works for old rows (full public URL) and new rows (just the file name)
function getPath(imageUrl) {
  if (!imageUrl) return null;
  const marker = `/${BUCKET}/`;
  const index = imageUrl.indexOf(marker);
  return index === -1 ? imageUrl : imageUrl.slice(index + marker.length);
}

// Year a memory belongs to (memory date first, upload date as backup)
function getYear(memory) {
  return String((memory.memory_date || memory.created_at || "").slice(0, 4));
}

function getType(memory) {
  return memory.media_type === "video" ? "video" : "image";
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function formatTripDate(dateString) {
  return new Date(dateString + "T00:00:00").toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
  });
}

function formatTripFull(dateString) {
  return new Date(dateString + "T00:00:00").toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function App() {
  const [memories, setMemories] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [memoryDate, setMemoryDate] = useState(() =>
    new Date().toLocaleDateString("en-CA"),
  );

  // Which card is open: null | "photos" | "videos" | "trips"
  const [activeSection, setActiveSection] = useState(null);
  const [openYear, setOpenYear] = useState(null);
  const contentRef = useRef(null);

  const [session, setSession] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [fullName, setFullName] = useState("");
  const [savingName, setSavingName] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const [friends, setFriends] = useState([]);
  const [friendsOpen, setFriendsOpen] = useState(false);

  const [trips, setTrips] = useState([]);
  const [eventsOpen, setEventsOpen] = useState(false);
  const [calMonth, setCalMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = useState(null);
  const [tripTitle, setTripTitle] = useState("");
  const [tripLocation, setTripLocation] = useState("");
  const [tripEndDate, setTripEndDate] = useState("");
  const [savingTrip, setSavingTrip] = useState(false);
  const tripFormRef = useRef(null);

  const isDeveloper =
    session?.user?.email?.trim().toLowerCase() ===
    DEVELOPER_EMAIL.trim().toLowerCase();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
    });

    const { data: listener } = supabase.auth.onAuthStateChange(
      (_event, newSession) => {
        setSession(newSession);
      },
    );

    return () => listener.subscription.unsubscribe();
  }, []);

  // Scroll the trip form into view when a date is picked
  useEffect(() => {
    if (selectedDate && tripFormRef.current) {
      tripFormRef.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  }, [selectedDate]);

  // Scroll to the opened section
  useEffect(() => {
    if (activeSection && contentRef.current) {
      contentRef.current.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  }, [activeSection]);

  async function loadFriends() {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .order("joined_at", { ascending: true });

    if (error) {
      console.error("Friends error:", error);
      return;
    }

    setFriends(data || []);
  }

  async function loadTrips() {
    const { data, error } = await supabase
      .from("trips")
      .select("*")
      .order("start_date", { ascending: true });

    if (error) {
      console.error("Trips error:", error);
      return;
    }

    setTrips(data || []);
  }

  useEffect(() => {
    async function loadMemories() {
      if (!session) {
        setMemories([]);
        setFriends([]);
        setTrips([]);
        setOpenYear(null);
        setActiveSection(null);
        return;
      }

      loadFriends();
      loadTrips();

      const { data, error } = await supabase
        .from("memories")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Supabase error:", error);
        return;
      }

      const rows = data || [];
      const paths = rows.map((row) => getPath(row.image_url)).filter(Boolean);

      const urlMap = {};
      if (paths.length > 0) {
        const { data: signed, error: signError } = await supabase.storage
          .from(BUCKET)
          .createSignedUrls(paths, 3600);

        if (signError) {
          console.error("Signed URL error:", signError);
        }

        (signed || []).forEach((item) => {
          if (item.signedUrl) urlMap[item.path] = item.signedUrl;
        });
      }

      setMemories(
        rows.map((row) => ({
          ...row,
          signed_url: urlMap[getPath(row.image_url)] || null,
        })),
      );
    }

    loadMemories();
  }, [session]);

  async function handleLogin(e) {
    e.preventDefault();

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error("Login error:", error);
      alert("Login failed. Check your email and password.");
      return;
    }

    setEmail("");
    setPassword("");
  }

  async function handleLogout() {
    setMenuOpen(false);
    setFriendsOpen(false);
    setEventsOpen(false);
    setSelectedDate(null);
    setOpenYear(null);
    setActiveSection(null);
    await supabase.auth.signOut();
  }

  async function handleSaveName(e) {
    e.preventDefault();
    if (!fullName.trim()) return;

    setSavingName(true);

    const { error } = await supabase.auth.updateUser({
      data: { full_name: fullName.trim() },
    });

    setSavingName(false);

    if (error) {
      console.error("Save name error:", error);
      alert("Could not save your name. Check the console.");
      return;
    }

    setFullName("");
    loadFriends();
  }

  async function handleAddMemory(e) {
    e.preventDefault();
    if (!title.trim()) return;

    if (file && file.size > MAX_FILE_MB * 1024 * 1024) {
      alert(
        `This file is larger than ${MAX_FILE_MB} MB. Please pick a smaller one.`,
      );
      return;
    }

    const form = e.currentTarget;
    setUploading(true);

    const mediaType =
      file && file.type.startsWith("video/") ? "video" : "image";
    let imagePath = null;

    if (file) {
      const ext = file.name.split(".").pop();
      const path = `${crypto.randomUUID()}.${ext}`;

      const { error: uploadError } = await supabase.storage
        .from(BUCKET)
        .upload(path, file);

      if (uploadError) {
        console.error("Upload error:", uploadError);
        alert("Upload failed. Check the console.");
        setUploading(false);
        return;
      }

      imagePath = path;
    }

    const { data, error } = await supabase
      .from("memories")
      .insert({
        title: title.trim(),
        description: description.trim(),
        image_url: imagePath,
        memory_date: memoryDate,
        media_type: mediaType,
      })
      .select()
      .single();

    if (error) {
      console.error("Insert error:", error);
      alert("Could not add memory. Check the console.");
      setUploading(false);
      return;
    }

    let signedUrl = null;
    if (imagePath) {
      const { data: signed } = await supabase.storage
        .from(BUCKET)
        .createSignedUrl(imagePath, 3600);
      signedUrl = signed?.signedUrl || null;
    }

    setUploading(false);
    setMemories([{ ...data, signed_url: signedUrl }, ...memories]);

    // Open the folder where the new memory was filed
    setActiveSection(mediaType === "video" ? "videos" : "photos");
    setOpenYear(memoryDate.slice(0, 4));

    setTitle("");
    setDescription("");
    setFile(null);
    setMemoryDate(new Date().toLocaleDateString("en-CA"));
    form.reset();
  }

  async function handleDeleteMemory(id) {
    if (!window.confirm("Delete this memory?")) return;

    const { error } = await supabase.from("memories").delete().eq("id", id);

    if (error) {
      console.error("Delete error:", error);
      alert("Could not delete memory. Check the console.");
      return;
    }

    setMemories(memories.filter((memory) => memory.id !== id));
  }

  async function handleAddTrip(e) {
    e.preventDefault();
    if (!selectedDate || !tripTitle.trim()) return;

    if (tripEndDate && tripEndDate < selectedDate) {
      alert("The end date can't be before the start date.");
      return;
    }

    setSavingTrip(true);

    const { error } = await supabase.from("trips").insert({
      title: tripTitle.trim(),
      location: tripLocation.trim() || null,
      start_date: selectedDate,
      end_date: tripEndDate || null,
    });

    setSavingTrip(false);

    if (error) {
      console.error("Add trip error:", error);
      alert("Could not add the trip. Check the console.");
      return;
    }

    setTripTitle("");
    setTripLocation("");
    setTripEndDate("");
    setSelectedDate(null);
    loadTrips();
  }

  async function handleDeleteTrip(id) {
    if (!window.confirm("Delete this trip?")) return;

    const { error } = await supabase.from("trips").delete().eq("id", id);

    if (error) {
      console.error("Delete trip error:", error);
      alert("Could not delete the trip. Check the console.");
      return;
    }

    setTrips(trips.filter((trip) => trip.id !== id));
  }

  function changeMonth(step) {
    setCalMonth(
      new Date(calMonth.getFullYear(), calMonth.getMonth() + step, 1),
    );
  }

  function openSection(name) {
    if (!session) {
      alert("Please log in first.");
      return;
    }
    setOpenYear(null);
    setActiveSection(activeSection === name ? null : name);
  }

  // ----- Calendar calculations -----
  const calYear = calMonth.getFullYear();
  const calMonthIndex = calMonth.getMonth();
  const monthPart = String(calMonthIndex + 1).padStart(2, "0");
  const firstWeekday = new Date(calYear, calMonthIndex, 1).getDay();
  const daysInMonth = new Date(calYear, calMonthIndex + 1, 0).getDate();
  const calendarCells = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const now = new Date();
  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;

  const monthStartKey = `${calYear}-${monthPart}-01`;
  const monthEndKey = `${calYear}-${monthPart}-${String(daysInMonth).padStart(2, "0")}`;
  const monthTrips = trips.filter(
    (trip) =>
      trip.start_date <= monthEndKey &&
      (trip.end_date || trip.start_date) >= monthStartKey,
  );

  // ----- Photos / videos and year folders -----
  const photoCount = memories.filter((m) => getType(m) === "image").length;
  const videoCount = memories.filter((m) => getType(m) === "video").length;

  const isVideoSection = activeSection === "videos";
  const typeMemories =
    activeSection === "photos" || activeSection === "videos"
      ? memories.filter(
          (m) => getType(m) === (isVideoSection ? "video" : "image"),
        )
      : [];

  const years = [...new Set(typeMemories.map(getYear))].sort((a, b) => b - a);

  const yearMemories = openYear
    ? typeMemories
        .filter((m) => getYear(m) === openYear)
        .sort((a, b) =>
          (b.memory_date || b.created_at).localeCompare(
            a.memory_date || a.created_at,
          ),
        )
    : [];

  const showFolders = !openYear || yearMemories.length === 0;

  return (
    <div className="website">
      <nav className="navbar">
        <h2>MILES &amp; MEMORIES ❤️</h2>

        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#trips">Trips</a>
          <a href="#memories">Memories</a>

          {/* Events dropdown with calendar */}
          <div className="events-menu">
            <button
              className="nav-friends-btn"
              onClick={() => {
                setEventsOpen(!eventsOpen);
                setFriendsOpen(false);
                setMenuOpen(false);
              }}
            >
              Events
            </button>

            {eventsOpen && (
              <div className="events-dropdown">
                {!session ? (
                  <p className="friends-dropdown-note">
                    Log in to see our trips.
                  </p>
                ) : (
                  <>
                    <div className="cal-header">
                      <button onClick={() => changeMonth(-1)}>‹</button>
                      <span>
                        {calMonth.toLocaleDateString("en-IN", {
                          month: "long",
                          year: "numeric",
                        })}
                      </span>
                      <button onClick={() => changeMonth(1)}>›</button>
                    </div>

                    <div className="cal-grid">
                      {WEEKDAYS.map((day) => (
                        <span className="cal-weekday" key={day}>
                          {day}
                        </span>
                      ))}

                      {calendarCells.map((day, index) => {
                        if (day === null) {
                          return (
                            <span className="cal-empty" key={`e${index}`} />
                          );
                        }

                        const dayKey = `${calYear}-${monthPart}-${String(day).padStart(2, "0")}`;
                        const dayTrips = trips.filter(
                          (trip) =>
                            trip.start_date <= dayKey &&
                            dayKey <= (trip.end_date || trip.start_date),
                        );

                        return (
                          <span
                            key={dayKey}
                            className={`cal-day${dayTrips.length ? " has-trip" : ""}${dayKey === todayKey ? " today" : ""}${dayKey === selectedDate ? " selected" : ""}`}
                            title={dayTrips
                              .map((trip) => trip.title)
                              .join(", ")}
                            onClick={() => setSelectedDate(dayKey)}
                          >
                            {day}
                          </span>
                        );
                      })}
                    </div>

                    {/* Trip form sits right under the calendar */}
                    {isDeveloper ? (
                      <form
                        className="trip-form"
                        onSubmit={handleAddTrip}
                        ref={tripFormRef}
                      >
                        <h4>Assign a trip</h4>

                        {selectedDate ? (
                          <>
                            <p className="trip-form-date">
                              📅 Start date: {formatTripDate(selectedDate)}
                            </p>
                            <input
                              type="text"
                              placeholder="Trip name"
                              value={tripTitle}
                              onChange={(e) => setTripTitle(e.target.value)}
                              required
                              autoFocus
                            />
                            <input
                              type="text"
                              placeholder="Location (optional)"
                              value={tripLocation}
                              onChange={(e) => setTripLocation(e.target.value)}
                            />
                            <label className="trip-end-label">
                              End date (optional)
                              <input
                                type="date"
                                min={selectedDate}
                                value={tripEndDate}
                                onChange={(e) => setTripEndDate(e.target.value)}
                              />
                            </label>
                            <button type="submit" disabled={savingTrip}>
                              {savingTrip ? "Saving..." : "Add Trip"}
                            </button>
                          </>
                        ) : (
                          <p className="trip-form-date">
                            👆 Click any date above to assign a trip.
                          </p>
                        )}
                      </form>
                    ) : (
                      <p className="trip-note">
                        Only the admin can assign trips.
                      </p>
                    )}

                    <div className="cal-trips">
                      {monthTrips.length === 0 ? (
                        <p className="friends-dropdown-note">
                          No trips this month.
                        </p>
                      ) : (
                        monthTrips.map((trip) => (
                          <div className="cal-trip" key={trip.id}>
                            <div>
                              <p className="cal-trip-name">✈️ {trip.title}</p>
                              <p className="cal-trip-info">
                                {trip.location ? `${trip.location} · ` : ""}
                                {formatTripDate(trip.start_date)}
                                {trip.end_date
                                  ? ` – ${formatTripDate(trip.end_date)}`
                                  : ""}
                              </p>
                            </div>
                            {isDeveloper && (
                              <button
                                className="cal-trip-delete"
                                onClick={() => handleDeleteTrip(trip.id)}
                                title="Delete trip"
                              >
                                🗑️
                              </button>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Friends dropdown */}
          <div className="friends-menu">
            <button
              className="nav-friends-btn"
              onClick={() => {
                setFriendsOpen(!friendsOpen);
                setMenuOpen(false);
                setEventsOpen(false);
              }}
            >
              Friends
              {session && (
                <span className="friends-badge">{friends.length}</span>
              )}
            </button>

            {friendsOpen && (
              <div className="friends-dropdown">
                {!session ? (
                  <p className="friends-dropdown-note">
                    Log in to see the gang.
                  </p>
                ) : (
                  <>
                    <p className="friends-dropdown-title">
                      <span>{friends.length}</span>{" "}
                      {friends.length === 1 ? "friend" : "friends"} in the gang
                    </p>

                    <ul className="friends-list">
                      {friends.map((friend) => (
                        <li key={friend.id}>
                          <div className="friend-mini-avatar">
                            {(friend.full_name || "F").charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="friend-mini-name">
                              {friend.full_name || "Friend"}
                            </p>
                            <p className="friend-mini-date">
                              Joined {formatDate(friend.joined_at)}
                            </p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            )}
          </div>

          {session && (
            <div className="profile-menu">
              <button
                className="avatar-btn"
                onClick={() => {
                  setMenuOpen(!menuOpen);
                  setFriendsOpen(false);
                  setEventsOpen(false);
                }}
              >
                {(session.user.user_metadata?.full_name || session.user.email)
                  .charAt(0)
                  .toUpperCase()}
              </button>

              {menuOpen && (
                <div className="profile-dropdown">
                  <p className="profile-name">
                    {session.user.user_metadata?.full_name || "Add your name"}
                  </p>
                  <p className="profile-email">{session.user.email}</p>

                  <form className="profile-form" onSubmit={handleSaveName}>
                    <input
                      type="text"
                      placeholder="Update your name"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                    />
                    <button type="submit" disabled={savingName}>
                      {savingName ? "Saving..." : "Save Name"}
                    </button>
                  </form>

                  <button className="logout-btn" onClick={handleLogout}>
                    Logout
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </nav>

      <section className="hero" id="home">
        <div className="hero-content">
          <p className="subtitle">LIFE IS BETTER TOGETHER</p>

          <h1>
            Collect Moments.
            <br />
            Not Things.
          </h1>

          <p className="description">
            Every trip has a story. Every picture holds a memory. Let's keep our
            friendship alive forever.
          </p>

          <button
            onClick={() =>
              document.getElementById("memories").scrollIntoView({
                behavior: "smooth",
              })
            }
          >
            Explore Our Memories →
          </button>
        </div>
      </section>

      <section className="memories" id="memories">
        <h2>Our Beautiful Memories</h2>
        <p>Every moment becomes a beautiful memory.</p>

        {/* Category cards: click to open */}
        <div className="memory-grid">
          <button
            className={`memory-card category-card${activeSection === "photos" ? " active" : ""}`}
            onClick={() => openSection("photos")}
          >
            <span className="category-icon">📸</span>
            <h3>Our Photos</h3>
            {session && <span className="category-count">{photoCount}</span>}
          </button>

          <button
            className={`memory-card category-card${activeSection === "videos" ? " active" : ""}`}
            onClick={() => openSection("videos")}
          >
            <span className="category-icon">🎥</span>
            <h3>Our Videos</h3>
            {session && <span className="category-count">{videoCount}</span>}
          </button>

          <button
            className={`memory-card category-card${activeSection === "trips" ? " active" : ""}`}
            onClick={() => openSection("trips")}
          >
            <span className="category-icon">🏕️</span>
            <h3>Our Trips</h3>
            {session && <span className="category-count">{trips.length}</span>}
          </button>
        </div>

        {session && !activeSection && (
          <p className="folders-empty">
            Tap Photos, Videos or Trips to open them.
          </p>
        )}

        {/* Opened section */}
        {session && activeSection && (
          <div className="section-content" ref={contentRef}>
            <div className="section-head">
              <h3>
                {activeSection === "photos" && "📸 Our Photos"}
                {activeSection === "videos" && "🎥 Our Videos"}
                {activeSection === "trips" && "🏕️ Our Trips"}
              </h3>
              <button
                className="folder-back"
                onClick={() => {
                  setActiveSection(null);
                  setOpenYear(null);
                }}
              >
                ✕ Close
              </button>
            </div>

            {/* Trips list */}
            {activeSection === "trips" && (
              <div className="trips-list">
                {trips.length === 0 ? (
                  <p className="folders-empty">
                    No trips yet. The admin can add them from the Events
                    calendar.
                  </p>
                ) : (
                  trips.map((trip) => (
                    <div className="trip-card" key={trip.id}>
                      <div className="trip-card-icon">✈️</div>
                      <div>
                        <h4>{trip.title}</h4>
                        <p>
                          {trip.location ? `📍 ${trip.location} · ` : ""}
                          {formatTripFull(trip.start_date)}
                          {trip.end_date
                            ? ` – ${formatTripFull(trip.end_date)}`
                            : ""}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Year folders for photos or videos */}
            {activeSection !== "trips" && showFolders && (
              <>
                {years.length === 0 ? (
                  <p className="folders-empty">
                    No {isVideoSection ? "videos" : "photos"} yet. Add one with
                    the form below!
                  </p>
                ) : (
                  <div className="folders-grid">
                    {years.map((year) => {
                      const inYear = typeMemories.filter(
                        (m) => getYear(m) === year,
                      );
                      const cover = inYear.find(
                        (m) => m.signed_url,
                      )?.signed_url;

                      return (
                        <button
                          className="folder-card"
                          key={year}
                          onClick={() => setOpenYear(year)}
                        >
                          <div className="folder-cover">
                            {cover ? (
                              isVideoSection ? (
                                <video src={cover} muted preload="metadata" />
                              ) : (
                                <img src={cover} alt={`${year} cover`} />
                              )
                            ) : (
                              <span>{isVideoSection ? "🎬" : "📁"}</span>
                            )}
                          </div>
                          <h3>{year}</h3>
                          <p>
                            {inYear.length}{" "}
                            {isVideoSection
                              ? inYear.length === 1
                                ? "video"
                                : "videos"
                              : inYear.length === 1
                                ? "photo"
                                : "photos"}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                )}
              </>
            )}

            {/* Inside a year folder */}
            {activeSection !== "trips" && !showFolders && (
              <>
                <div className="folder-bar">
                  <button
                    className="folder-back"
                    onClick={() => setOpenYear(null)}
                  >
                    ← All folders
                  </button>
                  <h3 className="folder-title">📂 {openYear}</h3>
                </div>

                <div className="memory-grid">
                  {yearMemories.map((memory) => (
                    <div className="memory-card" key={memory.id}>
                      {memory.signed_url &&
                        (isVideoSection ? (
                          <video
                            className="memory-image memory-video"
                            src={memory.signed_url}
                            controls
                            preload="metadata"
                          />
                        ) : (
                          <img
                            className="memory-image"
                            src={memory.signed_url}
                            alt={memory.title}
                          />
                        ))}
                      <h3>{memory.title}</h3>
                      <p>{memory.description}</p>
                      <button
                        className="delete-btn"
                        onClick={() => handleDeleteMemory(memory.id)}
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* Login form (logged out) / Add memory form (logged in) */}
        {!session ? (
          <form className="memory-form" onSubmit={handleLogin}>
            <h3>Friends Login</h3>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit">Login</button>
          </form>
        ) : (
          <form className="memory-form" onSubmit={handleAddMemory}>
            <h3>Add a Memory</h3>
            <input
              type="text"
              placeholder="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
            <textarea
              placeholder="What happened?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            <label className="memory-date-label">
              When did this happen?
              <input
                type="date"
                value={memoryDate}
                onChange={(e) => setMemoryDate(e.target.value)}
                required
              />
            </label>
            <label className="memory-date-label">
              Photo or video (max {MAX_FILE_MB} MB)
              <input
                type="file"
                accept="image/*,video/*"
                onChange={(e) => setFile(e.target.files[0] || null)}
              />
            </label>
            <button type="submit" disabled={uploading}>
              {uploading ? "Uploading..." : "Add Memory"}
            </button>
          </form>
        )}
      </section>

      <footer>Made with ❤️ by our gang.</footer>
    </div>
  );
}

export default App;
